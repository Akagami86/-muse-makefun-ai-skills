# Muse Make.fun AI Skills

This package contains two independent Agent Skills:

1. `makefun-supervisor` — audits competition choice, eligibility, build quality, submission readiness, risk, quota, and post-competition results.
2. `creative-strategist` — generates differentiated concepts and turns promising ideas into execution briefs.

## Important limitation

These are instruction skills, not a copy of ChatGPT or GPT-6. Installing them does not automatically connect Muse to this ChatGPT conversation or provide a live GPT reviewer. Direct GPT review requires a separately configured API/integration that Muse supports.

## Install from GitHub using skills.sh

1. Extract this ZIP.
2. Create a new GitHub repository, for example `muse-makefun-ai-skills`.
3. Upload the two skill folders and `README.md` while preserving this structure:

```text
muse-makefun-ai-skills/
├── README.md
├── makefun-supervisor/
│   └── SKILL.md
└── creative-strategist/
    └── SKILL.md
```

4. In Muse's supported terminal/skill installer, install each skill from your GitHub repository. The common skills.sh CLI pattern is:

```bash
npx skills add YOUR_GITHUB_USERNAME/muse-makefun-ai-skills --skill makefun-supervisor
npx skills add YOUR_GITHUB_USERNAME/muse-makefun-ai-skills --skill creative-strategist
```

Replace `YOUR_GITHUB_USERNAME` with your actual GitHub username. Confirm the exact command and compatibility in Muse's own skill installation interface/documentation before running it; browser-based Muse may not expose a terminal.

## Suggested activation prompts

Supervisor:
> Use the makefun-supervisor skill. Audit this Make.fun competition using its current official rules and evidence. Return the required Make.fun Supervisor Report. Do not submit anything.

Ideator:
> Use the creative-strategist skill. Research this opportunity, generate distinct concepts, shortlist the strongest, and produce a Creative Strategy Brief. Do not spend money or submit anything.

## Safety

Never put API keys, passwords, seed phrases, private keys, cookies, or tokens in these files or in a public repository. Keep owner approval for spending, publishing, wallet actions, and final submissions.
